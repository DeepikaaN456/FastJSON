package com.alibaba.json.bvt;

import com.alibaba.fastjson.parser.ParserConfig;

import junit.framework.TestCase;

@SuppressWarnings("deprecation")
public class JavaBeanMappingTest extends TestCase {
	
	public void test_0 () throws Exception {
	    ParserConfig.getGlobalInstance();
	}
}
